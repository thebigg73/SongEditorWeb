<template>
  <aside class="file-explorer" :class="{ open: open }"> 
    <div class="section">
      <h4>Files</h4>
      <button @click="pickRoot">Choose root folder</button>
      <div class="files-list">
        <div v-if="!rootHandle" class="empty">No folder selected</div>
        <table v-else class="file-table">
          <thead>
            <tr><th>Título</th><th>Artista</th></tr>
          </thead>
          <tbody>
            <tr v-for="f in files" :key="f.name" @click="openFile(f.handle)">
              <td>{{ f.title || f.name || '-' }}</td>
              <td>{{ f.artist || '-' }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="section">
      <h4>Setlists</h4>
      <button @click="pickSetRoot">Choose setlist folder</button>
      <div class="setlist-area">
        <div v-if="!setRoot">No folder selected</div>
        <div v-else>
          <div class="setlist-controls">
            <button @click="addSelected">Add selected to setlist</button>
            <button @click="saveSetlist">Save setlist</button>
          </div>
          <ul class="setlist">
            <li v-for="(s, i) in setlistItems" :key="i">{{ s.name }}</li>
          </ul>
        </div>
      </div>
    </div>
  </aside>
</template>

<script>
export default {
  name: 'FileExplorer',
  props: { open: { type: Boolean, default: false } },
  data() {
    return { rootHandle: null, files: [], setRoot: null, setFiles: [], selected: new Set(), setlistItems: [] };
  },
  methods: {
    async pickRoot() {
      if (!window.showDirectoryPicker) { alert('showDirectoryPicker not supported in this browser'); return; }
      try {
        const dir = await window.showDirectoryPicker();
        this.rootHandle = dir;
        this.files = [];
        for await (const [name, handle] of dir.entries()) {
          // include known extensions and files without any extension (OpenSong supports extensionless files)
          if (handle.kind === 'file' && (/\.(xml|ost|txt|song)$/i.test(name) || name.indexOf('.') === -1)) {
            const meta = await this.readMetadata(handle, name);
            this.files.push(Object.assign({ name, handle }, meta));
          }
        }
      } catch (err) {
        console.error('Error picking root', err);
      }
    },
    async pickSetRoot() {
      if (!window.showDirectoryPicker) { alert('showDirectoryPicker not supported in this browser'); return; }
      try {
        const dir = await window.showDirectoryPicker();
        this.setRoot = dir;
        this.setFiles = [];
        for await (const [name, handle] of dir.entries()) {
          // include files without extension as setlist candidates too
          if (handle.kind === 'file' && (/\.(xml|ost|txt|song)$/i.test(name) || name.indexOf('.') === -1)) {
            const meta = await this.readMetadata(handle, name);
            this.setFiles.push(Object.assign({ name, handle }, meta));
          }
        }
      } catch (err) {
        console.error('Error picking setlist root', err);
      }
    },
    async readMetadata(handle, name) {
      try {
        const file = await handle.getFile();
        const text = await file.text();
        // try XML parse first
        try {
          const parser = new DOMParser();
          const doc = parser.parseFromString(text, 'application/xml');
          const q = (names) => {
            for (const n of names) {
              const el = doc.querySelector(n);
              if (el && el.textContent) return el.textContent;
            }
            return '';
          };
          const title = q(['title','songtitle','name']);
          const artist = q(['artist','author','composer','creator','autor']);
          const key = q(['key','tonality','tone']);
          if (title || artist || key) return { title: title || undefined, artist: artist || undefined, key: key || undefined };
        } catch (e) {
          // ignore; try plain parsing below
        }

        // plain-text / OpenSong-like key:value parsing (handles extensionless files)
        const kv = (pattern) => {
          const m = text.match(new RegExp('^\\s*(?:' + pattern + ')\\s*[:=]\\s*(.+)$', 'im'));
          return m ? m[1].trim() : undefined;
        };
        const titleKv = kv('title|titulo|songtitle');
        const artistKv = kv('artist|composer|autor');
        const keyKv = kv('key|tonality|tone');

        if (titleKv || artistKv || keyKv) {
          return { title: titleKv || undefined, artist: artistKv || undefined, key: keyKv || undefined };
        }

        // last resort: first non-empty line
        const firstLine = text.split(/\r?\n/).find(l => l.trim());
        return { title: firstLine || name, artist: undefined, key: undefined };
      } catch (err) {
        console.error('readMetadata error', err);
        return { title: undefined, artist: undefined, key: undefined };
      }
    },

    async openFile(handle) {
      this.$emit('open-file', handle);
    },
    addSelected() {
      // add all files from setFiles to setlistItems
      for (const f of this.setFiles) {
        if (!this.setlistItems.find(si => si.name === f.name)) this.setlistItems.push({ name: f.name });
      }
    },
    async saveSetlist() {
      try {
        const handle = await window.showSaveFilePicker({ suggestedName: 'setlist.json', types:[{description:'JSON', accept:{'application/json':['.json']}}] });
        const writable = await handle.createWritable();
        await writable.write(JSON.stringify(this.setlistItems, null, 2));
        await writable.close();
        alert('Setlist saved');
      } catch (err) { console.error('Error saving setlist', err); alert('No se pudo guardar el setlist'); }
    }
  }
};
</script>

<style scoped>
.file-explorer {
  position: fixed;
  top: 48px;
  left: 0;
  bottom: 0;
  width: 0; /* collapsed by default */
  background: #0f0f0f;
  color: #fff;
  border-right: 1px solid #222;
  padding: 0 0 12px 0;
  overflow: hidden;
  z-index: 1150;
  transition: width 300ms ease, padding 300ms ease;
  pointer-events: none;
}
.file-explorer.open {
  width: 320px;
  padding: 12px;
  pointer-events: auto;
}
.file-explorer .section { margin-bottom: 16px; }
.files-list { max-height: calc(100vh - 200px); overflow-y: auto; }
.files-list ul { list-style: none; padding: 0; margin: 0; }
.files-list li { padding: 6px 8px; cursor: pointer; border-bottom: 1px solid #1a1a1a; }
.files-list li:hover { background: #1a1a1a; }
.file-table { width: 100%; border-collapse: collapse; font-family: 'Segoe UI', Tahoma, Arial, sans-serif; font-size: 13px; line-height: 1.2; }
.file-table th, .file-table td { padding: 4px 6px; text-align: left; border-bottom: 1px solid #1a1a1a; }
.file-table thead th { color: #ddd; font-weight: 600; }
.file-table tbody tr:hover { background: #2b2b2b; cursor: pointer; font-weight: 700; color: #fff; }
.setlist { list-style: none; padding: 0; margin: 8px 0; }
</style>