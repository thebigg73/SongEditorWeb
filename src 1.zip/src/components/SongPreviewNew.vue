<template>
  <aside class="preview-panel" :class="{fullscreen}" :style="panelStyle">
    <header class="preview-headerbar">
      <div class="drag-handle" @mousedown="startDrag" @touchstart.prevent="startDrag" title="Arrastrar para redimensionar vista previa"></div>
      <div class="toolbar">
        <!-- device views -->
        <button class="icon" @click="setMode('phone')" :title="'Phone / Teléfono'">
          <!-- phone svg -->
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="7" y="2" width="10" height="20" rx="2" stroke="currentColor" stroke-width="1.5" fill="none"/><circle cx="12" cy="18" r="0.8" fill="currentColor"/></svg>
        </button>
        <button class="icon" @click="setMode('tablet')" :title="'Tablet / Tableta'">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="4" y="3" width="16" height="18" rx="2" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
        </button>
        <!-- print/print-preview mode -->
        <button class="icon" @click="setMode('print')" :title="'Print / Impresión'">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 9V3h12v6" stroke="currentColor" stroke-width="1.5" fill="none"/><rect x="4" y="9" width="16" height="8" rx="1" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
        </button>
        <button class="icon" @click="rotateDevice" :title="'Rotate / Rotar'">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 12a9 9 0 1 0-3.5 7" stroke="currentColor" stroke-width="1.5" fill="none"/><path d="M21 3v6h-6" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
        </button>

        <button class="icon" @click="toggleFullscreen" :title="fullscreen ? 'Exit Fullscreen / Salir pantalla completa' : 'Fullscreen / Pantalla completa'">
          <svg v-if="!fullscreen" width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 9V3h6" stroke="currentColor" stroke-width="1.5"/><path d="M21 15v6h-6" stroke="currentColor" stroke-width="1.5"/></svg>
          <svg v-else width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 3H3v6" stroke="currentColor" stroke-width="1.5"/><path d="M21 9V3h-6" stroke="currentColor" stroke-width="1.5"/></svg>
        </button>

        <!-- autoscroll cycle -->
        <button class="icon" @click="cycleAutoscroll" :title="autoscrollTooltip">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 5v14" stroke="currentColor" stroke-width="1.5"/><path d="M18 11l-6-6-6 6" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
        </button>
        <!-- sync scroll (uses metadata) -->
        <button class="icon" @click="toggleSyncScroll" :title="'Sync scroll / Desplazamiento sincronizado'">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 12h3l3 8 4-16 3 8h4" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
        </button>

        <!-- separators then existing controls: transpose, font, close -->
        <div class="sep"></div>
        <button class="icon" @click="decreaseFont" :title="'Decrease font / Disminuir fuente'">A-</button>
        <button class="icon" @click="increaseFont" :title="'Increase font / Aumentar fuente'">A+</button>
        <button class="icon" @click="$emit('close')" :title="'Close / Cerrar'">✕</button>
      </div>
    </header>

    <div class="preview-body" :class="modeClass">
      <div class="preview-title">
        <div class="title">{{ song && song.title ? song.title : '' }}</div>
        <div class="artist">{{ song && song.author ? song.author : '' }}</div>
      </div>
      <div class="preview-content" ref="content" :style="previewStyle" v-html="formatearLyrics(song && song.lyrics ? song.lyrics : '')"></div>
    </div>
  </aside>
</template>

<script>
export default {
  name: "SongPreview",
  props: { song: Object, updateSongCallback: Function },
  data() {
    return {
      fontSize: 18,
      mode: 'normal', // normal | phone | tablet | print
      rotated: false,
      fullscreen: false,
      panelWidth: 520,
      panelHeight: null,
      dragging: false,
      dragStartX: 0,
      startWidth: 520,
      autoscrollState: 0, // 0 off, 1..3 speeds
      autoscrollTimer: null,
      syncScrollActive: false,
      syncAnimation: null,
      syncStartTimeout: null
    };
  },
  computed: {
    previewStyle() {
      const style = { fontSize: this.fontSize + 'px', whiteSpace: 'normal' };
      if (this.mode === 'phone') {
        if (this.rotated) { style.width = '640px'; style.height = '360px'; } else { style.width = '360px'; style.height = '640px'; }
      } else if (this.mode === 'tablet') {
        if (this.rotated) { style.width = '1024px'; style.height = '768px'; } else { style.width = '768px'; style.height = '1024px'; }
      } else if (this.mode === 'print') {
        style.width = '100%'; style.height = 'auto';
      }
      return style;
    },
    panelStyle() { return this.fullscreen ? {} : { width: this.panelWidth + 'px' }; },
    modeClass() {
      if (this.mode === 'phone') return this.rotated ? 'phone rotated' : 'phone';
      if (this.mode === 'tablet') return this.rotated ? 'tablet rotated' : 'tablet';
      if (this.mode === 'print') return this.rotated ? 'print rotated' : 'print';
      return 'normal';
    },
    autoscrollTooltip() { const map = ['Autoscroll off / Auto desplazamiento (apagado)','Autoscroll speed 1 / Velocidad 1','Autoscroll speed 2 / Velocidad 2','Autoscroll speed 3 / Velocidad 3']; return map[this.autoscrollState]; }
  },
  methods: {
    setMode(m) { 
      if (this.mode === m) { this.mode = 'normal'; this.rotated = false; } else { this.mode = m; }
      try { localStorage.setItem('previewMode', this.mode); } catch (e) {
  // Ignorar error de localStorage
}
    },
    rotateDevice() { 
      if (this.mode === 'phone' || this.mode === 'tablet') {
        this.rotated = !this.rotated;
      } else {
        this.mode = 'phone';
        this.rotated = false;
      }
      try { localStorage.setItem('previewRotated', this.rotated ? '1' : '0'); } catch (e) {
  // Ignorar error de localStorage
}
    },

    toggleFullscreen() { this.fullscreen = !this.fullscreen; if (this.fullscreen) { document.body.style.overflow = 'hidden'; } else { document.body.style.overflow = ''; } },

    escapeHtml(str) {
      return String(str || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
    },

    formatearLyrics(texto) {
      if (!texto) return "";
      const columnas = texto.split("!--");
      const htmlColumnas = columnas.map(columna => {
        const lineas = columna.trim().split("\n");
        const contenido = lineas.map(linea => {
          const trimmed = linea.trim();
          const sectionMatch = trimmed.match(/^\[(.+)\]$/);
          if (sectionMatch) {
            const name = this.escapeHtml(sectionMatch[1]);
            const isChorus = /chorus/i.test(sectionMatch[1]);
            return isChorus ? `<div class="section chorus">${name}</div>` : `<div class="section">${name}</div>`;
          }
          if (trimmed.startsWith('.')) {
            const sinPunto = trimmed.replace(/^\./, '');
            const escaped = this.escapeHtml(sinPunto).replace(/([A-G](?:#|b)?(?:m|maj|min|dim|aug|sus)?\d*)/g, "<span class='chord'>$1</span>");
            return `<div class="line chords">${escaped}</div>`;
          }
          return `<div class="line lyrics">${this.escapeHtml(linea)}</div>`;
        }).join("\n");
        return `<div class="column">${contenido}</div>`;
      }).join("");
      return `<div class="columns">${htmlColumnas}</div>`;
    },

    // autoscroll: cycle 0->1->2->3->0
    cycleAutoscroll() {
      this.stopAutoscroll();
      this.autoscrollState = (this.autoscrollState + 1) % 4;
      if (this.autoscrollState > 0) this.startAutoscroll(this.autoscrollState);
    },
    startAutoscroll(speedLevel) {
      const speeds = [0, 20, 40, 80]; // pixels per second
      const pxPerSec = speeds[speedLevel] || 0;
      if (!pxPerSec) return;
      const intervalMs = 50;
      this.autoscrollTimer = setInterval(() => {
        const el = this.$refs.content;
        if (!el) return;
        el.scrollTop = Math.min(el.scrollHeight - el.clientHeight, el.scrollTop + (pxPerSec * intervalMs / 1000));
        if (el.scrollTop >= el.scrollHeight - el.clientHeight) this.stopAutoscroll();
      }, intervalMs);
    },
    stopAutoscroll() { if (this.autoscrollTimer) { clearInterval(this.autoscrollTimer); this.autoscrollTimer = null; } this.autoscrollState = 0; },

    // sync scroll using metadata: wait song.delay then scroll over song.duration seconds
    toggleSyncScroll() {
      if (this.syncScrollActive) { this.stopSyncScroll(); return; }
      const delay = (this.song && this.song.delay) ? Number(this.song.delay) : 0;
      const duration = (this.song && this.song.duration) ? Number(this.song.duration) : 0;
      if (!duration || duration <= 0) { alert('Song duration missing or zero (set metadata)'); return; }
      const el = this.$refs.content;
      if (!el) return;
      el.scrollTop = 0;
      this.syncScrollActive = true;
      this.syncStartTimeout = setTimeout(() => {
        const start = performance.now();
        const from = 0;
        const to = el.scrollHeight - el.clientHeight;
        const run = (now) => {
          if (!this.syncScrollActive) return;
          const t = (now - start) / (duration * 1000);
          if (t >= 1) { el.scrollTop = to; this.stopSyncScroll(); return; }
          el.scrollTop = from + (to - from) * t;
          this.syncAnimation = requestAnimationFrame(run);
        };
        this.syncAnimation = requestAnimationFrame(run);
      }, delay * 1000);
    },
    stopSyncScroll() {
      this.syncScrollActive = false;
      if (this.syncStartTimeout) { clearTimeout(this.syncStartTimeout); this.syncStartTimeout = null; }
      if (this.syncAnimation) { cancelAnimationFrame(this.syncAnimation); this.syncAnimation = null; }
    },

    // keep existing controls
    transposeUp() {
      const s = this.transposeSong(1);
      if (typeof this.updateSongCallback === 'function') return this.updateSongCallback(s);
      this.$emit('update-song', s);
    },
    transposeDown() {
      const s = this.transposeSong(-1);
      if (typeof this.updateSongCallback === 'function') return this.updateSongCallback(s);
      this.$emit('update-song', s);
    },
    transposeSong(semitones) {
      if (!this.song || !this.song.lyrics) return this.song;
      const notas = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
      const bemoles = { "Db":"C#", "Eb":"D#", "Gb":"F#", "Ab":"G#", "Bb":"A#" };
      const moverNota = (nota) => {
        if (bemoles[nota]) nota = bemoles[nota];
        const base = nota.match(/^[A-G](#|b)?/);
        if (!base) return nota;
        const resto = nota.slice(base[0].length);
        const idx = notas.indexOf(base[0]);
        if (idx === -1) return nota;
        let nuevoIdx = (idx + semitones + notas.length) % notas.length;
        return notas[nuevoIdx] + resto;
      };
      const lines = this.song.lyrics.split('\n');
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (line.trim().startsWith('.')) {
          const leading = line.match(/^\s*\.?/)[0];
          const rest = line.replace(/^\s*\.?\s*/, '');
          const transformed = rest.replace(/([A-G](?:#|b)?(?:m|maj|min|dim|aug|sus)?\d*)/g, (m) => moverNota(m));
          lines[i] = leading + transformed;
        }
      }
      return {
        ...this.song,
        lyrics: lines.join('\n'),
        key: this.song.key ? moverNota(this.song.key) : this.song.key
      };
    },

    increaseFont() { this.fontSize = Math.min(72, this.fontSize + 2); },
    decreaseFont() { this.fontSize = Math.max(8, this.fontSize - 2); },

    startDrag(e) {
      this.dragging = true;
      this.dragStartX = e.touches ? e.touches[0].clientX : e.clientX;
      this.startWidth = this.panelWidth;
      window.addEventListener('mousemove', this.onDrag);
      window.addEventListener('touchmove', this.onDrag, {passive:false});
      window.addEventListener('mouseup', this.stopDrag);
      window.addEventListener('touchend', this.stopDrag);
    },
    onDrag(e) {
      if (!this.dragging) return;
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      const delta = clientX - this.dragStartX;
      this.panelWidth = Math.max(240, Math.min(window.innerWidth - 40, this.startWidth + delta));
      e.preventDefault?.();
    },
    stopDrag() {
      this.dragging = false;
      try { localStorage.setItem('previewWidth', String(this.panelWidth)); } catch (e) {
  console.error('Error guardando previewWidth:', e);
}
      window.removeEventListener('mousemove', this.onDrag);
      window.removeEventListener('touchmove', this.onDrag);
      window.removeEventListener('mouseup', this.stopDrag);
      window.removeEventListener('touchend', this.stopDrag);
    }
  },
  mounted() {
    // ensure no leftover timers
    try {
      const w = localStorage.getItem('previewWidth');
      const m = localStorage.getItem('previewMode');
      const r = localStorage.getItem('previewRotated');
      if (w) this.panelWidth = Math.max(240, Math.min(window.innerWidth - 40, Number(w)));
      if (m) this.mode = m;
      if (r) this.rotated = r === '1';
    } catch(e) { /* ignore */ }
  },
  beforeUnmount() {
    this.stopAutoscroll();
    this.stopSyncScroll();
    this.stopDrag();
  }
};
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;700&display=swap');
.preview-panel {
  position: fixed;
  top: 60px;
  right: 12px;
  width: 520px;
  max-width: calc(100vw - 40px);
  max-height: calc(100vh - 80px);
  border: 1px solid #444;
  border-radius: 6px;
  background: #1e1e1e;
  color: #fff;
  display: flex;
  flex-direction: column;
  z-index: 1400;
  box-shadow: 0 6px 18px rgba(0,0,0,0.5);
}
.preview-panel.fullscreen {
  top: 0; left: 0; right: 0; bottom: 0; width: auto; height: auto; max-height: none; border-radius: 0;
}
.preview-headerbar { display:flex; align-items:center; justify-content:space-between; padding:8px; background: rgba(0,0,0,0.6); border-bottom:1px solid #333; }
.preview-headerbar .drag-handle { width:14px; height:30px; cursor:col-resize; background:rgba(255,255,255,0.03); border-radius:4px; margin-right:8px; }
.preview-headerbar .drag-handle .label { margin-left:6px; font-size:0.95rem; }
.toolbar { display:flex; align-items:center; gap:6px; }
.toolbar .icon { width:34px; height:30px; display:inline-flex; align-items:center; justify-content:center; background:transparent; border:none; color:#ddd; cursor:pointer; border-radius:4px; }
.toolbar .icon:hover { background:#2b2b2b; color:#fff; transform:scale(1.02); }
.toolbar .sep { width:1px; height:22px; background:#333; margin:0 6px; }
.preview-body { padding:12px; overflow:hidden; display:flex; flex-direction:column; flex:1; }
.preview-title { margin-bottom:8px; }
.preview-title .title { font-weight:700; font-size:1.1rem; }
.preview-title .artist { opacity:0.9; font-size:0.95rem; margin-top:2px; }
.preview-content { overflow:auto; background:transparent; padding:6px; border-radius:4px; min-height:120px; flex:1; }

/* columns for column-break */
.columns { display:flex; gap:20px; }
.column { flex:1; min-width:200px; padding-right:10px; border-right:1px dashed #444; }
.column:last-child { border-right:none; }

/* device modes */
.preview-body.normal .preview-content { width:100%; }
.preview-body.phone .preview-content { width:360px; height:640px; }
.preview-body.phone.rotated .preview-content { width:640px; height:360px; }
.preview-body.tablet .preview-content { width:768px; height:1024px; }
.preview-body.tablet.rotated .preview-content { width:1024px; height:768px; }

/* stronger hover on file list was set earlier; keep preview styles readable */
.section { font-weight:700; text-decoration:underline; margin:8px 0; display:block; }
.line.lyrics { margin:2px 0; }
.line.chords { margin:2px 0; color:#4FC3F7; }
.chord { color:#4FC3F7; font-weight:700; }
</style>
