<template>
  <aside class="preview-panel" :class="{fullscreen}">
    <header class="preview-headerbar">
      <div class="drag-handle">☰ <span class="label">Preview</span></div>
      <div class="toolbar">
        <!-- device views -->
        <button class="icon" @click="setMode('phone')" :title="'Phone / Teléfono'">
          <!-- phone svg -->
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="7" y="2" width="10" height="20" rx="2" stroke="currentColor" stroke-width="1.5" fill="none"/><circle cx="12" cy="18" r="0.8" fill="currentColor"/></svg>
        </button>
        <button class="icon" @click="setMode('tablet')" :title="'Tablet / Tableta'">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="4" y="3" width="16" height="18" rx="2" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
        </button>
        <button class="icon" @click="rotateDevice" :title="'Rotate / Rotar'">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 12a9 9 0 1 0-3.5 7" stroke="currentColor" stroke-width="1.5" fill="none"/><path d="M21 3v6h-6" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
        </button>
        <button class="icon" @click="toggleFullscreen" :title="fullscreen ? 'Exit Fullscreen / Salir pantalla completa' : 'Fullscreen / Pantalla completa'">
          <svg v-if="!fullscreen" width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 9V3h6" stroke="currentColor" stroke-width="1.5"/><path d="M21 15v6h-6" stroke="currentColor" stroke-width="1.5"/></svg>
          <svg v-else width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 3H3v6" stroke="currentColor" stroke-width="1.5"/><path d="M21 9V3h-6" stroke="currentColor" stroke-width="1.5"/></svg>
        </button>

        <!-- autoscroll cycle -->
        <button class="icon" @click="cycleAutoscroll" :title="autoscrollTooltip">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 5v14" stroke="currentColor" stroke-width="1.5"/><path d="M18 11l-6-6-6 6" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
        </button>
        <!-- sync scroll (uses metadata) -->
        <button class="icon" @click="toggleSyncScroll" :title="'Sync scroll / Desplazamiento sincronizado'">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 12h3l3 8 4-16 3 8h4" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
        </button>

        <!-- separators then existing controls: transpose, font, close -->
        <div class="sep"></div>
        <button class="icon" @click="transposeUp" :title="'Transpose + / Subir tono'">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 5v14" stroke="currentColor" stroke-width="1.5"/><path d="M5 12h14" stroke="currentColor" stroke-width="1.5"/></svg>
        </button>
        <button class="icon" @click="transposeDown" :title="'Transpose - / Bajar tono'">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 5v14" stroke="currentColor" stroke-width="1.5"/><path d="M19 12H5" stroke="currentColor" stroke-width="1.5"/></svg>
        </button>
        <button class="icon" @click="decreaseFont" :title="'Decrease font / Disminuir fuente'">A-</button>
        <button class="icon" @click="increaseFont" :title="'Increase font / Aumentar fuente'">A+</button>
        <button class="icon" @click="$emit('close')" :title="'Close / Cerrar'">✕</button>
      </div>
    </header>
  </aside>
</template>


<script>
export default {
  name: "SongPreview",
  props: { song: Object },
  data() {
    return {
      fontSize: 18,
      mode: 'normal', // normal | phone | tablet
      rotated: false,
      fullscreen: false,
      autoscrollState: 0, // 0 off, 1..3 speeds
      autoscrollTimer: null,
      syncScrollActive: false,
      syncAnimation: null,
      syncStartTimeout: null
    };
  },
  computed: {
    previewStyle() { return { fontSize: this.fontSize + 'px', whiteSpace: 'normal' }; },
    modeClass() { return this.mode === 'phone' ? (this.rotated ? 'phone rotated' : 'phone') : this.mode === 'tablet' ? (this.rotated ? 'tablet rotated' : 'tablet') : 'normal'; },
    autoscrollTooltip() { const map = ['Autoscroll off / Auto desplazamiento (apagado)','Autoscroll speed 1 / Velocidad 1','Autoscroll speed 2 / Velocidad 2','Autoscroll speed 3 / Velocidad 3']; return map[this.autoscrollState]; }
  },
  methods: {
    setMode(m) { if (this.mode === m) { this.mode = 'normal'; this.rotated = false; } else { this.mode = m; } },
    rotateDevice() { this.rotated = !this.rotated; },
    toggleFullscreen() { this.fullscreen = !this.fullscreen; },

    // autoscroll: cycle 0->1->2->3->0
    cycleAutoscroll() {
      this.stopAutoscroll();
      this.autoscrollState = (this.autoscrollState + 1) % 4;
      if (this.autoscrollState > 0) this.startAutoscroll(this.autoscrollState);
    },
    startAutoscroll(speedLevel) {
      const speeds = [0, 20, 40, 80]; // pixels per second
      const pxPerSec = speeds[speedLevel] || 0;
      if (!pxPerSec) return;
      const intervalMs = 50;
      this.autoscrollTimer = setInterval(() => {
        const el = this.$refs.content;
        if (!el) return;
        el.scrollTop = Math.min(el.scrollHeight - el.clientHeight, el.scrollTop + (pxPerSec * intervalMs / 1000));
        if (el.scrollTop >= el.scrollHeight - el.clientHeight) this.stopAutoscroll();
      }, intervalMs);
    },
    stopAutoscroll() { if (this.autoscrollTimer) { clearInterval(this.autoscrollTimer); this.autoscrollTimer = null; } this.autoscrollState = 0; },

    // sync scroll using metadata: wait song.delay then scroll over song.duration seconds
    toggleSyncScroll() {
      if (this.syncScrollActive) { this.stopSyncScroll(); return; }
      const delay = (this.song && this.song.delay) ? Number(this.song.delay) : 0;
      const duration = (this.song && this.song.duration) ? Number(this.song.duration) : 0;
      if (!duration || duration <= 0) { alert('Song duration missing or zero (set metadata)'); return; }
      const el = this.$refs.content;
      if (!el) return;
      el.scrollTop = 0;
      this.syncScrollActive = true;
      this.syncStartTimeout = setTimeout(() => {
        const start = performance.now();
        const from = 0;
        const to = el.scrollHeight - el.clientHeight;
        const run = (now) => {
          if (!this.syncScrollActive) return;
          const t = (now - start) / (duration * 1000);
          if (t >= 1) { el.scrollTop = to; this.stopSyncScroll(); return; }
          el.scrollTop = from + (to - from) * t;
          this.syncAnimation = requestAnimationFrame(run);
        };
        this.syncAnimation = requestAnimationFrame(run);
      }, delay * 1000);
    },
    stopSyncScroll() {
      this.syncScrollActive = false;
      if (this.syncStartTimeout) { clearTimeout(this.syncStartTimeout); this.syncStartTimeout = null; }
      if (this.syncAnimation) { cancelAnimationFrame(this.syncAnimation); this.syncAnimation = null; }
    },

    // keep existing controls
    transposeUp() { this.$emit('update-song', this.transposeSong(1)); },
    transposeDown() { this.$emit('update-song', this.transposeSong(-1)); },
    transposeSong(semitones) {
      if (!this.song || !this.song.lyrics) return this.song;
      const notas = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
      const bemoles = { "Db":"C#", "Eb":"D#", "Gb":"F#", "Ab":"G#", "Bb":"A#" };
      const moverNota = (nota) => {
        if (bemoles[nota]) nota = bemoles[nota];
        const base = nota.match(/^[A-G](#|b)?/);
        if (!base) return nota;
        const resto = nota.slice(base[0].length);
        const idx = notas.indexOf(base[0]);
        if (idx === -1) return nota;
        let nuevoIdx = (idx + semitones + notas.length) % notas.length;
        return notas[nuevoIdx] + resto;
      };
      const lines = this.song.lyrics.split('\n');
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (line.trim().startsWith('.')) {
          const leading = line.match(/^\s*\.?/)[0];
          const rest = line.replace(/^\s*\.?\s*/, '');
          const transformed = rest.replace(/([A-G](?:#|b)?(?:m|maj|min|dim|aug|sus)?\d*)/g, (m) => moverNota(m));
          lines[i] = leading + transformed;
        }
      }
      return {
        ...this.song,
        lyrics: lines.join('\n'),
        key: this.song.key ? moverNota(this.song.key) : this.song.key
      };
    },

    increaseFont() { this.fontSize = Math.min(72, this.fontSize + 2); },
    decreaseFont() { this.fontSize = Math.max(8, this.fontSize - 2); }
  },
  mounted() {
    // ensure no leftover timers
  },
  beforeUnmount() {
    this.stopAutoscroll();
    this.stopSyncScroll();
  }
};
</script>

<style>
@import url('https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;700&display=swap');

.preview-window {
  position: fixed;
  top: 80px;
  left: 80px;
  width: 600px;
  min-width: 300px;
  height: 400px;
  resize: both;
  overflow: auto;
  border: 1px solid #444;
  border-radius: 6px;
  background: #1e1e1e;
  color: #fff;
  padding: 15px;
  font-family: 'Roboto Mono', monospace;
  z-index: 1400;
}
.preview-toolbar {
  cursor: move;
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}
.preview-header { margin-top: 8px; margin-bottom: 8px; }
.preview-header .title { font-weight: 700; font-size: 1.2em; }
.preview-header .artist { opacity: 0.9; font-size: 0.95em; margin-top: 2px; }

.preview-content {
  white-space: normal; /* ajuste de línea automático */
  line-height: 1.4;
}
.section { font-weight: 700; text-decoration: underline; margin: 8px 0; display: block; }
.section.chorus { background: rgba(255,255,255,0.1); padding: 4px 8px; border-radius: 4px; display: inline-block; }
.line.lyrics { margin: 2px 0; }
.line.chords { margin: 2px 0; color: #4FC3F7; }
.chord { color: #4FC3F7; font-weight: 700; }

</style>