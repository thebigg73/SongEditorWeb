<template>
  <header class="toolbar">
    <button class="hamburger explorer" @click="$emit('toggle-explorer')" title="Explorer / Explorador">
      <span class="bars">☰</span>
      <svg class="icon-svg" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="currentColor" d="M10 4H4a2 2 0 0 0-2 2v2h20V8a2 2 0 0 0-2-2h-8l-2-2zM2 10v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6H2z"/></svg>

    </button>

    <button @click="$emit('nuevo-archivo')">Nuevo</button>
    <button @click="$emit('abrir-archivo')">Abrir</button>
    <button @click="$emit('guardar-archivo')">Guardar</button>
    <button @click="$emit('guardar-como')">Guardar como</button>
    <button @click="$emit('open-help')">?</button>
    <button @click="$emit('edit-metadata')">Metadatos</button>
    <button @click="$emit('convert-ug')" title="Convertir (pegado desde Ultimate-Guitar)">⎘</button>
    <button @click="$emit('toggle-theme')" :title="modo==='dark' ? 'Cambiar a claro' : 'Cambiar a oscuro'">{{ modo==='dark' ? '☀' : '☾' }}</button>
    <button @click="$emit('toggle-shortcuts')">Atajos</button>

    <div class="spacer"></div>

    <!-- transpose controls moved from preview -->
    <button @click="$emit('transpose-down')" title="Transpose - / Bajar tono">♪−</button>
    <button @click="$emit('transpose-up')" title="Transpose + / Subir tono">♪+</button>

    <button class="hamburger preview" @click="$emit('toggle-preview')" title="Preview / Vista previa">
      <span class="bars">☰</span>
      <svg class="icon-svg" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="currentColor" d="M12 5c-7 0-10 6-10 7s3 7 10 7 10-6 10-7-3-7-10-7zm0 11a4 4 0 1 1 0-8 4 4 0 0 1 0 8z"/></svg>

    </button>
  </header>
</template>

<script>
export default { name: "MainToolbar", props: ["modo"] };
</script>

<style scoped>
.toolbar { display:flex; align-items:center; gap:8px; padding:6px 10px; }
.hamburger { display:inline-flex; align-items:center; gap:8px; padding:6px 10px; background:transparent; border:1px solid #444; color:#fff; cursor:pointer; border-radius:4px; }
.hamburger .bars { font-weight:700; }
.hamburger .icon-svg { width:16px; height:16px; color:#ddd; }
.hamburger .label { display:none; }
.spacer { flex:1 }
</style>