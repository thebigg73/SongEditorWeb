<template>
  <div class="SongEditor">
    <textarea ref="lyricsTextarea" v-model="song.lyrics" rows="20" cols="80"></textarea>
  </div>
</template>

<script>
export default {
  name: "SongEditor",
  props: { modelValue: Object },
  computed: {
    song: {
      get() { return this.modelValue; },
      set(val) { this.$emit("update:modelValue", val); }
    }
  }
};
</script>

<style scoped>
.SongEditor {
  position: fixed;
  top: 48px; /* leave room for the toolbar */
  left: var(--explorer-left, 0);
  right: 0;
  bottom: 0;
  background: #000;
  z-index: 1;
  transition: left 300ms ease;
}
.SongEditor textarea {
  width: 100%;
  height: 100%;
  resize: none;
  border: none;
  background: #000;
  color: #fff;
  padding: 16px;
  box-sizing: border-box;
  font-family: monospace;
  font-size: 14px;
}
</style>