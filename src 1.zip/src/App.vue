<template>
  <div id="app">
    <MainToolbar 
      @toggle-preview="showPreview = !showPreview"
      @open-help="openHelp"
      @edit-metadata="mostrarMetadata = true"
      @toggle-shortcuts="mostrarAtajos = !mostrarAtajos"
      @nuevo-archivo="nuevoArchivo"
      @abrir-archivo="abrirArchivoDirecto"
      @guardar-archivo="guardarDirecto"
      @guardar-como="guardarComo"
    />
    <FileExplorer v-if="showExplorer" @open-file="openFileFromHandle" @close-explorer="showExplorer = false" />

    <!-- Editor ocupa toda la pantalla -->
    <SongEditor v-model="song" ref="editor" />

    <!-- Preview flotante -->
    <SongPreview 
      v-if="showPreview" 
      :song="song" 
      @update-song="song = $event"
      @close="showPreview = false" 
    />

    <!-- Modal de metadatos -->
    <div v-if="mostrarMetadata" class="modal-overlay">
      <div class="modal">
        <h3>Metadata</h3>

        <label>Title: <input v-model="song.title" placeholder="Ex. Don't Cry" /></label>
        <label>Artist: <input v-model="song.author" placeholder="Ex. Guns N' Roses" /></label>
        <label>Sticky notes: <textarea v-model="song.notes" placeholder="Personal Notes"></textarea></label>
        <label>Key: <input v-model="song.key" placeholder="Ex. C, G, Am" /></label>
        <label>Original key: <input v-model="song.originalKey" placeholder="Ex. G" /></label>
        <label>Capo: <input type="number" v-model="song.capo" placeholder="Ex. 3" /></label>
        <label>Tempo (bpm): <input type="number" v-model="song.tempo" placeholder="Ex. 120" /></label>
        <label>Time signature: <input v-model="song.timeSignature" placeholder="Ex. 4/4" /></label>
        <label>Instrument: <input v-model="song.instrument" placeholder="Ex. Guitar/Piano" /></label>
        <label>Song duration (s): <input type="number" v-model="song.duration" placeholder="Ex. 180" /></label>
        <label>Autoscroll delay (s): <input type="number" v-model="song.delay" placeholder="Ex. 5" /></label>
        <label>Tags: <input v-model="song.tags" placeholder="Ex. Rock, Church, Acoustic" /></label>
        <label>Presentation order: <input v-model="song.presentationOrder" placeholder="Ex. V1, C, V2, C" /></label>

        <div class="modal-buttons">
          <button @click="guardarMetadatos">Save Metadata</button>
          <button @click="cerrarModal">Close</button>
        </div>
      </div>
    </div>


    <!-- Panel de atajos -->
    <div v-if="mostrarAtajos" class="atajos">
      <p><strong>Alt + 1</strong> → [ ]</p>
      <p><strong>Alt + 2</strong> → [Intro]</p>
      <p><strong>Alt + 3</strong> → [Verse]</p>
      <p><strong>Alt + 4</strong> → [Pre-Chorus]</p>
      <p><strong>Alt + 5</strong> → [Chorus]</p>
      <p><strong>Alt + 6</strong> → [Bridge]</p>
      <p><strong>Alt + 7</strong> → [Solo]</p>
      <p><strong>Alt + 8</strong> → [Instrumental]</p>
      <p><strong>Alt + 9</strong> → [Outro]</p>
      <p><strong>Alt + T</strong> → TabBlock</p>
      <p><strong>Alt + G</strong> → GridBlock</p>
      <p><strong>Alt + C</strong> → Column Break</p>
    </div>
  </div>
</template>


<script>
import { XMLParser, XMLBuilder } from "fast-xml-parser";
import MainToolbar from "./components/MainToolbar.vue";
import SongEditor from "./components/SongEditor.vue";
import SongPreview from "./components/SongPreview.vue";
import FileExplorer from "./components/FileExplorer.vue";

export default {
  name: "App",
  components: { MainToolbar, SongEditor, SongPreview, FileExplorer },

  data() {
    return {
      mostrarMetadata: false,
      mostrarAtajos: false,
      showPreview: false,
      showExplorer: false,
      modo: null,
      song: {
        title: '',
        author: '',
        lyrics: '',
        notes: '',
        key: '',
        originalKey: '',
        capo: 0,
        tempo: 120,
        timeSignature: '4/4',
        instrument: '',
        duration: 0,
        delay: 0,
        tags: '',
        presentationOrder: ''
      },
      fileHandle: null,
      tabBlock: `;E|-------|\n;B|-------|\n;G|-------|\n;D|-------|\n;A|-------|\n;E|-------|`,
      gridBlock: `[ChordGrid]\n | C . . . | G . . . | Am . . . | F . D . | \n`
    };
  },

  methods: {
    toggleExplorer() { this.showExplorer = !this.showExplorer; },
    async openFileFromHandle(handle) {
      try {
        const file = await handle.getFile();
        const texto = await file.text();
        const parser = new XMLParser({ ignoreAttributes: false });
        const json = parser.parse(texto);
        this.song = json.song || this.song;
        this.fileHandle = handle;
      } catch (err) {
        console.error("Error opening file from handle:", err);
        alert("No se pudo abrir el archivo");
      }
    },
    guardarMetadatos() {
      alert("Metadatos guardados");
      this.mostrarMetadata = false;
    },
    nuevoArchivo() {
      this.song = {
        title: "",
        author: "",
        notes: "",
        key: "",
        originalKey: "",
        capo: "",
        tempo: "",
        timeSignature: "",
        instrument: "",
        duration: "",
        delay: "",
        tags: "",
        presentationOrder: "",
        lyrics: ""
      };
      this.mostrarMetadata = true;
    },
    cerrarModal() {
      this.mostrarMetadata = false;
    },
    openHelp() {
      alert("Tips de uso:\n- Usa Preview para simular dispositivos\n- Contacto: editor@correo.com");
    },
    insertarBloque(texto) {
      // Find textarea inside SongEditor child component
      const textarea = this.$refs.editor && this.$refs.editor.$refs && this.$refs.editor.$refs.lyricsTextarea;
      if (!textarea) return;
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      textarea.setRangeText(texto, start, end, "end");
      textarea.focus();
      const event = new Event("input", { bubbles: true });
      textarea.dispatchEvent(event);
    },

    async guardarComo() {
      try {
        const handle = await window.showSaveFilePicker({
          types: [{ description: "Archivo OpenSong", accept: { "application/xml": [".xml", ".ost"] } }]
        });
        const writable = await handle.createWritable();
        const builder = new XMLBuilder({ ignoreAttributes: false });
        const xml = builder.build({ song: this.song });
        await writable.write(xml);
        await writable.close();
        alert("Archivo guardado correctamente");
      } catch (err) {
        console.error("Error al guardar como:", err);
        alert("No se pudo guardar el archivo");
      }
    },
    async abrirArchivoDirecto() {
      try {
        const [handle] = await window.showOpenFilePicker();
        this.fileHandle = handle;
        const file = await handle.getFile();
        const texto = await file.text();
        const parser = new XMLParser({ ignoreAttributes: false });
        const json = parser.parse(texto);
        this.song = json.song;
      } catch (err) {
        console.error("Error al abrir:", err);
        alert("No se pudo abrir el archivo");
      }
    },
    async guardarDirecto() {
      try {
        if (!this.fileHandle) {
          alert("Primero abre un archivo para poder guardarlo");
          return;
        }
        const writable = await this.fileHandle.createWritable();
        const builder = new XMLBuilder({ ignoreAttributes: false });
        const xml = builder.build({ song: this.song });
        await writable.write(xml);
        await writable.close();
        alert("Archivo sobrescrito correctamente");
      } catch (err) {
        console.error("Error al guardar:", err);
        alert("No se pudo guardar el archivo");
      }
    },
    // Transposición manual
    transponer(semitonos) {
      if (!this.song || !this.song.lyrics) return;
      const notas = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
      const bemoles = { "Db":"C#", "Eb":"D#", "Gb":"F#", "Ab":"G#", "Bb":"A#" };
      const moverNota = (nota) => {
        if (bemoles[nota]) nota = bemoles[nota];
        const base = nota.match(/^[A-G](#|b)?/);
        if (!base) return nota;
        const resto = nota.slice(base[0].length);
        const idx = notas.indexOf(base[0]);
        if (idx === -1) return nota;
        let nuevoIdx = (idx + semitonos + notas.length) % notas.length;
        return notas[nuevoIdx] + resto;
      };
      this.song.lyrics = this.song.lyrics.replace(
        /([A-G](?:#|b)?(?:m|maj|min|dim|aug|sus)?\d*)/g,
        (match) => moverNota(match)
      );
      if (this.song.key) {
        this.song.key = moverNota(this.song.key);
      }
    },
    transposeUp() { this.transponer(1); },
    transposeDown() { this.transponer(-1); },

    formatearLyrics(texto) {
      if (!texto) return "";
      const columnas = texto.split("!--");
      const htmlColumnas = columnas.map(columna => {
        const lineas = columna.trim().split("\n");
        let dentroDeChorus = false;
        const contenido = lineas.map(linea => {
          if (/^\[.*?\]$/.test(linea.trim())) {
            const nombreSeccion = linea.trim().replace(/\[|\]/g, "");
            if (/chorus/i.test(nombreSeccion)) {
              dentroDeChorus = true;
              return `<div class="highlight"><h4>${nombreSeccion}</h4>`;
            }
            if (dentroDeChorus) {
              dentroDeChorus = false;
              return `</div><h4 class="section">${nombreSeccion}</h4>`;
            }
            return `<h4 class="section">${nombreSeccion}</h4>`;
          }
          if (linea.trim().startsWith(".")) {
            const sinPunto = linea.trim().replace(/^\./, "");
            return `<div class="line chords">` + sinPunto.replace(
              /([A-G](?:#|b)?(?:m|maj|min|dim|aug|sus)?\d*)/g,
              "<span class='chord'>$1</span>"
            ) + `</div>`;
          }
          return `<div class="line lyrics">${linea}</div>`;
        }).join("\n");
        const cerrado = dentroDeChorus ? contenido + "</div>" : contenido;
        return `<div class="column">${cerrado}</div>`;
      }).join("");  
      return `<div class="columns">${htmlColumnas}</div>`;
    },

    handleKeydown(e) {
      const key = e.key.toUpperCase();
      if (e.altKey) {
        switch (key) {
          case "1": this.insertarBloque("[ ]"); break;
          case "2": this.insertarBloque("[Intro]"); break;
          case "3": this.insertarBloque("[Verse]"); break;
          case "4": this.insertarBloque("[Pre-Chorus]"); break;
          case "5": this.insertarBloque("[ChoruSs]"); break;
          case "6": this.insertarBloque("[Bridge]"); break;
          case "7": this.insertarBloque("[Solo]"); break;
          case "8": this.insertarBloque("[Instrumental]"); break;
          case "9": this.insertarBloque("[Outro]"); break;
          case "T": this.insertarBloque(this.tabBlock); break;
          case "G": this.insertarBloque(this.gridBlock); break;
          case "C": this.insertarBloque("\n!--\n"); break;
        }
        e.preventDefault();
      }
    }
  },

  mounted() {
    // named escape handler so it can be removed
    this._escapeHandler = (e) => { if (e.key === "Escape") this.cerrarModal(); };
    window.addEventListener("keydown", this.handleKeydown);
    window.addEventListener("keydown", this._escapeHandler);
  },
  beforeUnmount() {
    window.removeEventListener("keydown", this.handleKeydown);
    window.removeEventListener("keydown", this._escapeHandler);
  }
};
</script>

<style>
/* Base and layout */
html, body, #app { height: 100%; margin: 0; padding: 0; background: #000; color: #fff; font-family: Arial, sans-serif; }

/* Toolbar fixed at top */
header.toolbar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 48px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 10px;
  background: rgba(0,0,0,0.85);
  z-index: 1200;
}
header.toolbar button { margin: 0 6px; }

/* Editor fills remaining space below toolbar */
.SongEditor, .editor {
  position: fixed;
  top: 48px;
  left: 0;
  right: 0;
  bottom: 0;
  background: #000;
  z-index: 1;
}
.SongEditor textarea, .editor textarea {
  width: 100%;
  height: 100%;
  resize: none;
  border: none;
  background: #000;
  color: #fff;
  padding: 16px;
  box-sizing: border-box;
  font-family: monospace;
  font-size: 14px;
}

/* Modal and shortcuts must be above toolbar */
.modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.6); display: flex; justify-content: center; align-items: center; z-index: 1300; }
.modal { background: #292929; padding: 20px; border-radius: 8px; width: 400px; max-height: 80vh; overflow-y: auto; color: #fff; }

.atajos { position: fixed; bottom: 12px; left: 12px; background: #3ca88d; border-radius: 6px; padding: 8px; z-index: 1250; }
.atajos p { margin: 0; }

.preview-window { position: fixed; top: 60px; right: 20px; width: 600px; min-width: 300px; height: 400px; resize: both; overflow: auto; border: 1px solid #444; border-radius: 6px; background: #1e1e1e; color: #fff; padding: 15px; font-family: monospace; z-index: 1100; }

/* Utility and content styles kept minimal */
.chord { white-space: pre; font-family: monospace; color: #4FC3F7; font-weight: bold; }
.columns { display: flex; gap: 20px; }
.column { flex: 1; min-width: 200px; padding-right: 10px; border-right: 1px dashed #ccc; }
.column:last-child { border-right: none; }

button { margin: 0 6px; padding: 6px 10px; background: #383838; color: #fff; border: 1px solid #444; cursor: pointer; }
button:hover { background: #555; }

</style>